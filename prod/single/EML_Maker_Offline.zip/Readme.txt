##################################
#   Offline Setup Instructions   #
##################################

You'll want to download the zip file, extract its contents into a safe folder on your computer.

You bookmark that file on your computer, in your browser. The offline version of EML Maker has the right equipment to run directly from your machine without accessing the online version.

BUT, the best version is always the most up-to-date; so, what the offline version will do: it will ping the online version and see if it can access it. If it can access the online version it will redirect you there. So, everyone wins.

If you have the "old version" of EML Maker saved locally on your computer, EML Maker will tell you the next time you access the online version that there is a new version available, and you'll simply need to overwrite the file you downloaded on your computer with a new one.
